<!DOCTYPE html>
<html>
<head>
    <title>santrikoding.com</title>
</head>
<body>
    <h3><?php echo e($data['name']); ?></h3>
    <h4><?php echo e($data['body']); ?></h4>
   
    <p>Terimakasih</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/auth/kirimEmail.blade.php ENDPATH**/ ?>