

<?php $__env->startSection('content'); ?>
<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-box">
                <div class="form-title-wrap">
                    <div>
                        <h3 class="title"><?php echo e($subTitle); ?></h3>
                        <p class="font-size-14">Silahkan kelola data konfirmasi pembayaran di tabel bawah!</p>
                    </div>
                </div>
                <div class="form-content">
                    <div class="table-form table-responsive">
                        <div class="mb-2">
                            <?php if(session('berhasil')): ?>    
                                <div class="alert bg-primary text-white alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                    <?php echo e(session('berhasil')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <table class="table" id="example2">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">ID Pesanan</th>
                                    <th scope="col">Member</th>
                                    <th scope="col">Reklame</th>
                                    <th scope="col">Tanggal Bayar</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1;?>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <th><?php echo e($item->id_pesanan); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->lokasi); ?></td>
                                        <td><?php echo e($item->tanggal_bayar); ?></td>
                                        <td>
                                            <div class="table-content">
                                                <a href="/detail-pembayaran/<?php echo e($item->id_konfirmasi_pembayaran); ?>" class="theme-btn theme-btn-small" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- end form-box -->
        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/konfirmasiPembayaran/dataKonfirmasiPembayaran.blade.php ENDPATH**/ ?>