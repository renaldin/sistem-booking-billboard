

<?php $__env->startSection('content'); ?>
<section>
    <div class="row"> 
        <div class="col-lg-6">
            <div class="form-box booking-detail-form">
                <div class="form-title-wrap">
                    <h3 class="title">Detail Pesanan</h3>
                </div><!-- end form-title-wrap -->
                <div class="form-content">
                    <div class="card-item shadow-none radius-none mb-0">
                        <div class="card-body p-0">
                            <ul class="list-items list-items-2 py-3">
                                <li><span>Nama Lengkap:</span><?php echo e($user->nama); ?></li>
                                <li><span>Email:</span><?php echo e($user->email); ?></li>
                                <li><span>Alamat:</span><?php echo e($user->alamat); ?></li>
                                <li><span>Nomor Telepon:</span><?php echo e($user->nomor_telepon); ?></li>
                                <li><span>Nama Perusahaan:</span><?php echo e($user->nama_perusahaan); ?></li>
                                <li><span>Alamat Perusahaan:</span><?php echo e($user->alamat_perusahaan); ?></li><br>
                                <li><span>ID Pesanan:</span><?php echo e($order->id_pesanan); ?></li>
                                <li><span>Tanggal:</span><?php echo e(date('d F Y', strtotime($order->tanggal))); ?></li>
                                <li><span>Checkin Pasang:</span><?php echo e(date('d F Y', strtotime($order->cekin_pasang))); ?></li>
                                <li><span>Checkout Pasang:</span><?php echo e(date('d F Y', strtotime($order->cekout_pasang))); ?></li>
                                <li><span>Tambah Cetak:</span><?php echo e($order->tambah_cetak); ?></li>
                                <li>
                                    <span>Status:</span>
                                    <?php if($order->status_order === 'Batal'): ?>
                                        <span class="badge badge-danger text-white"><?php echo e($order->status_order); ?></td></span>
                                    <?php elseif($order->status_order === 'Dibooking'): ?>
                                        <span class="badge badge-primary text-white"><?php echo e($order->status_order); ?></td></span>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <b>
                                        <span>Harga:</span>
                                        <?php if($order->harga !== null): ?>
                                            <?= 'Rp ' . number_format($order->harga, 2, ',', '.'); ?>
                                        <?php else: ?>
                                            Menunggu verifikasi dari Admin
                                        <?php endif; ?>
                                    </b>
                                </li>
                                <li>
                                    <span>Star:</span>
                                    <?php if($order->star !== NULL): ?>
                                    <span class="ratings align-items-center">
                                        <?php for ($i=0; $i < $order->star; $i++) { ?>
                                            <i class="la la-star"></i>
                                        <?php } ?>
                                        <?php for ($i=0; $i < 5-$order->star; $i++) { ?>
                                            <i class="la la-star-o"></i>
                                        <?php } ?>
                                    </span>
                                    <?php else: ?>
                                        Belum Ada
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Review Dari Customer:</span> 
                                    
                                </li>
                                <li>
                                    
                                    <?php if($order->review  !== NULL): ?>
                                        <?php echo e($order->review); ?>

                                    <?php else: ?>
                                        Belum Ada
                                    <?php endif; ?>
                                </li>
                                <br>
                                <li><span>Tanggal Pembayaran:</span><?php echo e(date('d F Y', strtotime($pembayaran->tanggal_bayar))); ?></li>
                            </ul>
                            <span>Bukti Pembayaran</span>
                            <div class="table-responsive pb-4">
                                <center>
                                <img src="<?php echo e(asset('foto_bukti_bayar/'.$pembayaran->upload_BT)); ?>" width="90%" alt="Pembayaran <?php echo e($user->nama); ?>">
                                </center>
                            </div>
                        </div>
                    </div><!-- end card-item -->
                </div><!-- end form-content -->
            </div><!-- end form-box -->
        </div><!-- end col-lg-4 -->
        <div class="col-lg-6">
            <div class="form-box booking-detail-form">
                <div class="form-title-wrap">
                    <h3 class="title">Detail Reklame</h3>
                </div><!-- end form-title-wrap -->
                <div class="form-content">
                    <div class="card-item shadow-none radius-none mb-0">
                        <div class="card-img pb-4">
                            <center>
                                <img src="<?php echo e(asset('foto_reklame/'.$reklame->gambar)); ?>" style="width: 90%;" alt="<?php echo e($reklame->lokasi); ?>">
                            </center>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-items list-items-2 py-3">
                                <li><span>Lokasi:</span><?php echo e($reklame->lokasi); ?></li>
                                <li><span>Ukuran:</span><?php echo e($reklame->ukuran); ?></li>
                                <li><span>Orientation Page:</span><?php echo e($reklame->orientation_page); ?></li>
                                <li><span>Penerangan:</span><?php echo e($reklame->penerangan); ?></li>
                                <li><span>Jarak Pandang:</span><?php echo e($reklame->jarak_pandang); ?></li>
                                <li><span>Jumlah Sisi:</span><?php echo e($reklame->jumlah_sisi); ?></li>
                                <li><span>Situasi Lalu Lintas:</span><?php echo e($reklame->situasi_lalulintas); ?></li>
                                <li><span>Situasi Sekitar:</span><?php echo e($reklame->situasi_sekitar); ?></li>
                                <li><span>Target Audiens:</span><?php echo e($reklame->target_audiens); ?></li>
                            </ul>
                            <span>Google Maps</span>
                            <div class="table-responsive pb-4">
                                <?= $reklame->google_maps?>
                            </div>
                        </div>
                    </div><!-- end card-item -->
                </div><!-- end form-content -->
            </div><!-- end form-box -->
        </div><!-- end col-lg-4 -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/konfirmasiPembayaran/detail.blade.php ENDPATH**/ ?>